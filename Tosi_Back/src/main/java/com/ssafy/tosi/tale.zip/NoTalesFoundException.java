package com.ssafy.tosi.tale;

public class NoTalesFoundException extends Exception {
    public NoTalesFoundException(String message) {
        super(message);
    }
}
